<?=$form ?>
<div>
<?php  echo ' <img src="'.RAPYD_LIBRARIES.'action/document-new.png" id="iddt" border="0" style="vertical-align:middle;" />'?>
</div>
<table width='100%' class="bordetabla" >
	<tr>
		<td class='subtitulotabla'>C&oacute;digo</td>
		<td><?=$codigo?></td>
		<td class='subtitulotabla'>Tipo</td>
		<td><?=$tipo?></td>
		<td class='subtitulotabla'>Clase</td>
		<td align='right'><?=$clase?></td>
		<td class='subtitulotabla'>Activo</td>
		<td align='right'><?=$activo?></td>		
	</tr>
	<tr>
		<td class='subtitulotabla'>Alterno</td>
		<td><?=$alterno?></td>
		<td class='subtitulotabla'>Unidad</td>
		<td><?=$unidad?></td>
		<td class='subtitulotabla'>Comision</td>
		<td><?=$comision?></td>
		<td class='subtitulotabla'>Serial</td>
		<td align='right'><?=$serial?></td>		
	</tr>
	<tr>
		<td class='subtitulotabla'>Caja</td>
		<td><?=$caja?></td>
		<td class='subtitulotabla'>Clave</td>
		<td><?=$clave?></td>
		<td class='subtitulotabla'>UxCaja</td>
		<td><?=$uxcajas?></td>
		<td class='subtitulotabla'>Decimal</td>
		<td align='right'><?=$decimal?></td>		
	</tr>
	<tr>
		<td class='subtitulotabla'>Barras</td>
		<td><?=$barras?></td>
		<td colspan='6'></td>
	</tr>
	<tr>
		<td class='subtitulotabla'>Descripci&oacute;n</td>
		<td colspan='5'><?=$descrip?></td>
		<td class='subtitulotabla'>Peso Kg</td>
		<td align='right'><?=$peso?></td>
	</tr>
	<tr>
		<td></td>
		<td colspan='5'><?=$descrip2?></td>
		<td class='subtitulotabla'>Garant&iacute;a</td>
		<td align='right'><?=$garantia?> d&iacute;as </td>
	</tr>
	<tr>
		<td class='subtitulotabla'>Marca</td>
		<td colspan='5'><?=$marca?></td>
		<td class='subtitulotabla'>Modelo</td>
		<td ><?=$modelo?></td>
	</tr>
		<td class='subtitulotabla'>Departamento </td>
		<td colspan='8'><?=$dpto?> </td>
	</tr>
	<tr>
		<td class='subtitulotabla'>L&iacute;nea </td>
		<td id='td_linea' colspan='8'><?=$linea?> </td>
	</tr>
	<tr>
		<td class='subtitulotabla'>Grupo </td>
		<td id='td_grupo' colspan='8'><?=$grupo?></td>
	</tr>
</table><br>

<table width='100%' class="bordetabla">
	<tr>
		<td>
			<table>
				<tr>
					<td class='subtitulotabla'>Promedio</td>
					<td align='right'><?=$promedio?></td>
				</tr><tr>
					<td class='subtitulotabla'>Ultimo</td>
					<td align='right'><?=$ultimo?></td> 
				</tr><tr>
					<td class='subtitulotabla'>Dolares</td>
					<td align='right'><?=$us?></td>
				</tr><tr>
					<td class='subtitulotabla'>I.V.A.</td>
					<td align='right'><?=$iva?>%</td>
				</tr><tr>
					<td class='subtitulotabla'>Ventas</td>
					<td align='right'><?=$venta?></td>
				</tr>
			</table>
		</td>
		<td>
			<table width='100%'>
				<tr>
					<th>Margen</th>
					<th>Precio</th>
					<th>Precio + IVA</th>
				</tr>
				<tr>
					<td align='right'><?=$margen1?></td>
					<td align='right'><?=$base1?></td>
					<td align='right'><?=$precio1?></td>
				</tr>
				<tr>
					<td align='right'><?=$margen2?></td>
					<td align='right'><?=$base2?></td>
					<td align='right'><?=$precio2?></td>
				</tr>
				<tr>
					<td align='right'><?=$margen3?></td>
					<td align='right'><?=$base3?></td>
					<td align='right'><?=$precio3?></td>
				</tr>
				<tr>
					<td align='right'><?=$margen4?></td>
					<td align='right'><?=$base4?></td>
					<td align='right'><?=$precio4?></td>
				</tr>
			</table>
		</td>
		<td  align='right'>
			<table>
				<tr>
					<td class='subtitulotabla'>M&iacute;nima</td>
					<td align='right'><?=$minima?></td>
				</tr><tr>
					<td class='subtitulotabla'>M&aacute;xima</td>
					<td align='right'><?=$maxima?></td>
				</tr><tr>
					<td class='subtitulotabla'>Ordena</td>
					<td align='right'><?=$ordena?></td>
				</tr><tr>
					<td class='subtitulotabla'>P.Desp</td>
					<td align='right'><?=$pdesp?></td>
				</tr><tr>
					<td class='subtitulotabla'>Actual</td>
					<td align='right'><?=$actual?></td>
				</tr>
			</table>
		</td>
	</tr>
</table><br>

<table width='100%' class="bordetabla">
	<tr>
		<td>
			<table>
				<tr>
					<td class='subtitulotabla'>Proveedor</td>
					<td class='subtitulotabla'>Fecha</td>
					<td class='subtitulotabla'>Precio</td>
				</tr><tr>
					<td><?=$prov1  ?></td>
					<td nowrap="nowrap"><?=$pfecha1?></td>
					<td><?=$prepro1?></td>
				</tr><tr>
					<td><?=$prov2?></td>
					<td nowrap="nowrap"><?=$pfecha2?></td>
					<td><?=$prepro2?></td>
				</tr><tr>
					<td><?=$prov3?></td>
					<td nowrap="nowrap"><?=$pfecha3?></td>
					<td><?=$prepro3?></td>
				</tr>
			</table>
		</td>
		<td>
			<table>
				<tr>
					<td class='subtitulotabla'>Calcular Precio en base a</td>
					<td><?=$formcal?></td>
				</tr><tr>
					<td class='subtitulotabla'>Redondear</td>
					<td><?=$redecen?></td>
				</tr>
			</table>
		</td>
		<td>
<div style="height:80;">
	<table>
		<tr>
			<th>Almacen </th>
			<th>Cantidad</th>
		</tr>
		<?php
		foreach($alma AS $sal){
			echo '<tr><td>'.$sal['alma'].'</td><td>'.$sal['existen'].'</td></tr>';
		}
		?>
	</table>
</div>
		</td>
	</tr>
</table>
<?=$control ?>
<?=form_close() ?>
	<!--
	<div id="tags">
	<ul id="tabs_example_one" class="subsection_tabs">
		<li><a class="active" href="#one">One</a></li>
		<li><a class="" href="#two">Two</a></li>

	</ul>
	<div style="" id="one"><p>This is the simplest example of a set of tabs.</p></div>
	<div style="display: none;" id="two"><p>Note that the styling for the tabs is done with CSS, not the Control.Tabs script.</p></div>
	<script>
		new Control.Tabs('tabs_example_one');
	</script>
</div>
-->